# MAKEPASS
Make a secure password!
Just run makepass.

No guarantee that this will make you invincible.


by William @ Peep Software
