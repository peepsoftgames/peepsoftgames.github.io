/*********************************************
 * Description - Make secure password with GodClock
 * Author - William King
 * Date - Nov 06 2023
 * *******************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define SIZE 35

char newpass[SIZE];

unsigned long GodClock() {
    unsigned int low, high;
    __asm__ volatile("rdtsc" : "=a" (low), "=d" (high));
    unsigned long long cycles = ((unsigned long long)high << 32) | low;
    return cycles;
}

void main(void){
    //puts("MAKEPASS Password:");
    for(int i = 0;i != SIZE;i++){
        newpass[i] = (GodClock()%(122-48))+48; //All ASCII characters
    }
    puts(newpass);
#ifdef _WIN32
    system("pause"); // stupid
#endif
    exit(0);
}
