// Quicktimer by William King, makes a quick timer

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>


int main(int argc, char* argv[]){
//unsigned int timeleft;
if (argc == 1){
puts("QuickTimer by Vilyaem peepsoftgames.github.io thekenyaz@yandex.com\n Usage:\n quicktimer (unsigned int seconds)\n");
exit(1);
}
if(clock == -1){
puts("Quicktimer does not have access to the time, clock_t clock is -1!\n");
exit(2);
}
unsigned int timeleft = atoi(argv[1]);
printf("Starting Quicktimer Ctrl-C to stop. Time left %d \n", timeleft);

while (timeleft != 0){
timeleft -= 1; 
printf("Time left: %d\n", timeleft);
sleep(1);
}
printf("Timer has finished, enjoy your day. Glory to the Father, the Son, and the Holy Spirit\n");
exit(0);
}
