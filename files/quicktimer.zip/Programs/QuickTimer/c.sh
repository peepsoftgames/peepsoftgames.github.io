#!/bin/sh
#Complation script
clear
echo "Compiling."
rm quicktimer
tcc quicktimer.c -o quicktimer
cp quicktimer /usr/bin/
echo "WITHOUT ARGS"
./quicktimer
echo "WITH ARGS"
./quicktimer 30
