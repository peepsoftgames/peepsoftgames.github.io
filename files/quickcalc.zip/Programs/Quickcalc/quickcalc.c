// A simple calculator, if no arguments do wizard mode.

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <math.h>

int main(int argc, char* argv[]){

if (argc == 1) { puts("Quickcalculator 1Add 2Sub 3Mul 4Div"); exit(1);}
// Get numbers
unsigned int value1 = atoi(argv[1]);
unsigned int value2 = atoi(argv[3]);

// Determine operation
unsigned int operation = atoi(argv[2]); // addition subtraction multiplication division
// Do calculation and print
int finalvalue;

if (operation == 1){finalvalue = value1 + value2;}
if (operation == 2){finalvalue = value1 - value2;}
if (operation == 3){finalvalue = value1 * value2;}
if (operation == 4){finalvalue = value1 / value2;}

printf("%d\n", finalvalue);
exit(0);
}
