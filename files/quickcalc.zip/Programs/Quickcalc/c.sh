#!/bin/sh
clear
printf "Compiling\n"
rm quickcalc
#gcc quickcalc.c -o quickcalc
tcc quickcalc.c -o quickcalc
cp quickcalc /usr/bin/
#gdb quickcalc
