-- Cyr2Glag is a lua app that converts Cyrillic to Glagolithic
cyrillic_alphabet = {"А","Б","В","Г","Д","Е","Ж","З","И","Й","К","Л","М","Н","О","П","Р","С","Т","У","Ф","Х","Ц","Ч","Ш","Щ","Ъ","Ы","Ь","Э","Ю","Я","а","б","в","г","д","е","ж","з","и","й","к","л","м","н","о","п","р","с","т","у","ф","х","ц","ч","ш","щ","ъ","ы","ь","э","ю","я","ё","Ё"}
glagolitic_alphabet = {"Ⰰ","Ⰲ","Ⰴ","Ⰱ","Ⰳ","Ⱄ","Ⰶ","Ⰸ","Ⰻ","Ⰺ","Ⰽ","Ⰾ","Ⰿ","Ⱀ","Ⱂ","Ⱃ","Ⱄ","Ⱅ","Ⱆ","Ⱇ","Ⱈ","Ⱊ","Ⱋ","Ⱌ","Ⱍ","Ⱎ","Ⱏ","Ⱔ","Ⱑ","Ⱒ","Ⱓ","Ⱕ","Ⱖ","Ⱗ","Ⱘ","Ⱙ","Ⱚ","Ⱛ","Ⱜ","Ⱝ","Ⱞ","Ⱟ","ⰰ","ⰱ","ⰲ","ⰳ","ⰴ","ⰵ","ⰶ","ⰷ","ⰸ","ⰹ","ⰺ","ⰻ","ⰼ","ⰽ","ⰾ","ⰿ","ⱀ","ⱁ","ⱂ","ⱃ","ⱄ","ⱅ","ⱆ","ⱇ","ⱈ","ⱉ","ⱜ","ⱝ"}

-- Define the conversion function
function convert_to_glagolitic(input_text)
    local output_text = ""
    for i = 1, #input_text do
        local char = string.sub(input_text, i, i)
        local index = nil
        for j = 1, #cyrillic_alphabet do
            if string.find(cyrillic_alphabet[j], char) ~= nil then
                index = j
                break
            end
        end
        if index then
            output_text = output_text .. glagolitic_alphabet[index]
        else
            output_text = output_text .. char
        end
    end
    return output_text
end


function get_user_input()
    print("Enter Cyrillic text to convert to Glagolitic:")
    local input_text = io.read()
    local output_text = convert_to_glagolitic(input_text)
    print("Glagolitic output:")
    print(output_text)
    print("Would you like to convert more text? (y/n)")
    local choice = io.read()
    if choice == "y" then
        get_user_input()
    else
        print("Goodbye!")
    end
end


get_user_input()
