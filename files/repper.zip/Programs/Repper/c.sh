#/bin/sh
#Compilation script
clear
echo "Compiling"
rm repper
tcc repper.c -o repper
cp repper /usr/bin/
./repper
