// Repper helps the user pace their reps and sets 

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

int main(int argc, char* argv[]){

if (argc == 1){
puts("Repper by Vilyaem peepsoftgames.github.io thekenyaz@yandex.com\n Usage: \n repper (unsigned int sets) (unsigned int reps) (unsigned int reptime) (unsignd int settime)\n 3 Beeps is a set completion, 1 beep is rep completion, this uses the 'beep' program. \n");
exit(1);
}

unsigned int sets = atoi(argv[1]);
unsigned int reps =  atoi(argv[2]);
unsigned int reptime = atoi(argv[3]);
unsigned int settime = atoi(argv[4]);
printf("Starting repper with %d Sets and %d Reps  Rep Rest: %d Set Rest: %d \n", sets, reps, reptime, settime);
printf("Waiting 3 Seconds to make sure you are ready\n");
sleep(3);
for ( sets >  0; sets--;){

for (unsigned int newreps = reps; newreps >  0; newreps --){
sleep(reptime);
system("beep");
printf("Rep completed, reps left in the set: %d\n", newreps);
}
system("beep;beep;beep");
printf("Set completed, sets left in the exercise: %d\n", sets);
sleep(settime);
}

printf("Repper is finished\n");
exit(0);
}
