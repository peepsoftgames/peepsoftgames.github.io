/*********************************************
 * Description - Based Term Grx 
 * Modified for use with Harelet.
 * Author - William King
 * Date - Sep 13 2023
 * *******************************************/

#include <string.h>

//Always have a 2:1 ratio if you want a square picture
//Terminals are vertically stretched
#define RESX 98
#define RESY 48

//Center X & Y
#define CX	49
#define CY	24

//Colours
#define BLACK "\x1b[30m"
#define RED "\x1b[31m"
#define GREEN "\x1b[32m"
#define YELLOW "\x1b[33m"
#define BLUE "\x1b[34m"
#define MAGENTA "\x1b[35m"
#define CYAN "\x1b[36m"
#define WHITE "\x1b[37m"

#define IBLACK "\x1b[30;1m"
#define IRED "\x1b[31;1m"
#define IGREEN "\x1b[32;1m"
#define IYELLOW "\x1b[33;1m"
#define IBLUE "\x1b[34;1m"
#define IMAGENTA "\x1b[35;1m"
#define ICYAN "\x1b[36;1m"
#define IWHITE "\x1b[37;1m"

#define BGC_BLACK "\x1b[40m"
#define BGC_RED "\x1b[41m"
#define BGC_GREEN "\x1b[42m"
#define BGC_YELLOW "\x1b[43m"
#define BGC_BLUE "\x1b[44m"
#define BGC_MAGENTA "\x1b[45m"
#define BGC_CYAN "\x1b[46m"
#define BGC_WHITE "\x1b[47m"

#define BGC_IBLACK "\x1b[40;1m"
#define BGC_IRED "\x1b[41;1m"
#define BGC_IGREEN "\x1b[42;1m"
#define BGC_IYELLOW "\x1b[43;1m"
#define BGC_IBLUE "\x1b[44;1m"
#define BGC_IMAGENTA "\x1b[45;1m"
#define BGC_ICYAN "\x1b[46;1m"
#define BGC_IWHITE "\x1b[47;1m"

char screen[RESY][RESX];


/*********************************************
 * Description - Clear the screen
 * Author - William King
 * Date - Sep 13 2023
 * *******************************************/
void ClrScr(){
	//printf("\x1b[2J");
	for(int i = 0; i != 32;i++)
		puts("");

	for(int i = 0; i != RESY; i++){

		for(int j = 0; j != RESX; j++){

			screen[i][j] = ' ';

		}


	}


}

/*********************************************
 * Description - Render all the cells to the screen, splashing
 * Author - William King
 * Date - Sep 13 2023
 * *******************************************/
void Splash(){
	puts("");
	for(int i = 0; i != RESY; i++){

		for(int j = 0; j != RESX; j++){

			printf("%c",screen[j][i]);

		}

		puts("");

	}


}

/*********************************************
 * Description - Put a character onto the screen 
 * Author - William King
 * Date - Sep 13 2023
 * *******************************************/
void DrawChar(int x, int y, char content){
	//Make sure it's in the screen
	assert(x <= RESX && y <= RESY);

	screen[x][y] = content;
}

/*********************************************
 * Description - Put a string onto the screen
 * Author - William King
 * Date - Sep 13 2023
 * *******************************************/
void DrawString(int x, int y, char str[128]){

	//Make sure origin is in the screen
	assert(x <= RESX || y <= RESY);

	//Make sure the string wont run off the screen
	assert(x + strlen(str) <= RESX);

	for(int i; i != strlen(str);i++){

		DrawChar(x+i,y,str[i]);

	}


}


/*********************************************
 * Description - Draw a square
 * Author - William King
 * Date - Sep 13 2023
 * *******************************************/
void DrawSquare(int x, int y, int length, char fill){

	//Make sure shape is not ridiculous
	assert(x <= RESX && y <= RESY);
	assert(x+length <= RESX && y+length <= RESY);

	for(int i = 0; i != length;i++){

		int j = 0;
		while (j != 0){
			DrawChar(x+j,y+i,fill);
			j++;
		}

	}


}


/*********************************************
* Description -  Fill the entire screen with a character
* Author - William King
* Date - Sep 15 2023
* *******************************************/
void DrawFill(char fill){
	for(int i = 0; i != RESY; i++){
		for(int j = 0; j != RESX; j++){
			screen[i][j] = fill;

		}
	}

}



/*********************************************
* Description - Set the colour
* Author - William King
* Date - Sep 13 2023
* *******************************************/
void SetColour(char * colour){
	printf("%s",colour);
}


/*********************************************
* Description - Reset the colour
* Author - William King
* Date - Sep 13 2023
* *******************************************/
void ResetColour(char * colour){
    printf("\x1b[0m");
}
