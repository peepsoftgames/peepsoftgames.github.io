/*********************************************
* Description - BasedFileLib makes file I/O less like *nix and more like 
* TempleOS
* Author - William King
* Date - Sep 25 2023
* *******************************************/

#define MAX_LINES 100000
#define MAXLENGTH 512

char* ReadFile(const char* fileName) {
	FILE* file = fopen(fileName, "rb");
	if (file == NULL) {
		perror("Error opening file");
		return NULL;
	}

	fseek(file, 0, SEEK_END);
	long fileSize = ftell(file);
	rewind(file);

	char* fileContent = (char*)malloc(fileSize * sizeof(char));
	if (fileContent == NULL) {
		perror("Error allocating memory for file content");
		fclose(file);
		return NULL;
	}

	size_t readSize = fread(fileContent, sizeof(char), fileSize, file);
	if (readSize != fileSize) {
		perror("Error reading file");
		fclose(file);
		free(fileContent);
		return NULL;
	}

	fclose(file);
	return fileContent;
}

void WriteFile(const char* fileName, const char* content) {
	FILE* file = fopen(fileName, "wb");
	if (file == NULL) {
		perror("Error opening file");
	}

	size_t writeSize = fwrite(content, sizeof(char), strlen(content), file);
	if (writeSize != strlen(content)) {
		perror("Error writing to file");
		fclose(file);
	}

	fclose(file);
}


char* DeleteLine(char* str, unsigned int line_number) {
	char* lines[MAX_LINES];
	char* line;
	unsigned int current_line = 0;

	line = strtok(str, "\n");
	while (line != NULL && current_line < MAX_LINES) {
		lines[current_line++] = line;
		line = strtok(NULL, "\n");
	}

	// Delete the specified line
	if (line_number > 0 && line_number <= current_line) {
		for (unsigned int i = line_number - 1; i < current_line - 1; i++) {
			lines[i] = lines[i + 1];
		}
		current_line--;
	}

	// Reconstruct the string with remaining lines
	str[0] = '\0';
	for (unsigned int i = 0; i < current_line; i++) {
		strcat(str, lines[i]);
		strcat(str, "\n");
	}

	return str;
}



char* ReadLine(const char *str, unsigned int lineNum) {
	int currentLine = 1;
	size_t strLen = strlen(str);
	char *line = NULL;

	line = malloc(strLen + 1);
	if (line == NULL) {
		fprintf(stderr, "Error: memory allocation failed.\n");
		exit(1);
	}

	int lineStartIndex = 0;
	int lineEndIndex = 0;

	// Traverse through the string until the desired line or the end of the string
	while (currentLine <= lineNum && lineEndIndex < strLen) {
		// Find the start index of the current line
		while (lineStartIndex < strLen && (str[lineStartIndex] == '\n' || str[lineStartIndex] == '\r')) {
			lineStartIndex++;
			lineEndIndex++;
		}

		// Find the end index of the current line
		lineEndIndex = lineStartIndex;
		while (lineEndIndex < strLen && str[lineEndIndex] != '\n' && str[lineEndIndex] != '\r') {
			lineEndIndex++;
		}

		// Check if the desired line is found
		if (currentLine == lineNum) {
			// Copy the line to the allocated memory
			strncpy(line, str + lineStartIndex, lineEndIndex - lineStartIndex);
			line[lineEndIndex - lineStartIndex] = '\0';
			break;
		}

		// Move to the start of the next line
		currentLine++;
		lineStartIndex = lineEndIndex;
	}

	return line;
}

//BasedFileLib
