#!/bin/sh 
clear 
rm harelet 
rm hareletdvrk
tcc harelet.c -o harelet
tcc harelet.c -o hareletdvrk -D DVORAK
x86_64-w64-mingw32-gcc harelet.c -o harelet.exe
x86_64-w64-mingw32-gcc hareletdvrk.c -o hareletdvrk.exe
mv harelet.exe win32
mv hareletdvrk.exe win32
doas cp harelet /usr/bin/ 
gdb harelet
