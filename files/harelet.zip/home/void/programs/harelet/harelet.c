/*********************************************
 * Description - Harelet is a CAD and compiler program for CNC milling machines
 * Author - William King
 * Date - Sep 08 2023
 * *******************************************/

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <assert.h>
#include <stdint.h>

#include "based/basedfilelib.h"
#include "based/basedtermgrx.h"

#define DEEPNESS 5
#define MAXPOINT 4096
#define UNITS	"G20\n"
#define SPEED	20

typedef struct{
	uint32_t X;
	uint32_t Y;
	uint32_t down;
}point;

point points[MAXPOINT];

uint32_t X = 5;
uint32_t Y = 5;
uint32_t step = 5;
uint32_t down = 0;
uint32_t numpoints = 0;
char action;


/*********************************************
 * Description - Warn the user about something
 * Author - William King
 * Date - Sep 27 2023
 * *******************************************/
void Warn(char * s){
	printf("WARNING:");
	puts(s);
	putchar('\a');
	getchar();
}

/*********************************************
 * Description - Convert integers to strings, makes
 * source code more pretty.
 * Author - William King
 * Date - Sep 26 2023
 * *******************************************/
char * IntToString(uint32_t num){
	char * s;
	sprintf(s,"%d",num);
	return s;
}

/*********************************************
 * Description - Renders the screen
 * Author - William King
 * Date - Sep 08 2023
 * *******************************************/
void Render(){	
	ClrScr();
	puts("HARELET A CAD PROGRAM BY VILYAEM KENYAZ, PEEP SOFTWARE 2023");
	printf("Number of Points: %d X: %d Y: %d STEPSIZE: %d DWN?: %d\n",numpoints,X,Y,step,down);

	//Render points
	if(numpoints > 0){
		for(int i = 0;i != numpoints;i++){
			if(points[i].down == 0){
				DrawChar(points[i].X,points[i].Y,'U');

			}
			else{
				DrawChar(points[i].X,points[i].Y,'D');
			}
		}
	}

	//Render cursor
	DrawChar(X,Y,'&');

	Splash();

}

/*********************************************
 * Description - This function compiles instructions for CNC machines.
 * Author - William King
 * Date - Sep 08 2023
 * *******************************************/
void Compile(){

	char filename[64];
	char file[8192];
	char buffer[64];
	uint32_t choice;

	puts("Select your format\n1. RAW GCODE\n2. OPENSBP");
	scanf("%d",&choice);


	puts("Enter the filename");
	scanf("%s",filename);
	printf("Compiling %s...\n",filename);
	if(choice == 1){
		//Set the miller
		strcat(file,UNITS);
		strcat(file,"G0 X0 Y0 Z0\n");
		//Meat of instructions
		for(int i = 0;i != numpoints;i++){
			//Compose
			char instruction[64];
			strcat(instruction,"G0 X ");
			strcat(instruction,IntToString(points[i].X));
			strcat(instruction," Y ");
			strcat(instruction,IntToString(points[i].Y));
			if(points[i].down == 1){
				strcat(instruction," Z 5\n");
			}
			else{
				strcat(instruction," Z 0\n");
			}
			//Write to string
			strcat(file,instruction);
		}

		//Finish
		strcat(file,"G0 X0 Y0 Z0\n");
		WriteFile(filename,file);
	}
	else if(choice == 2){
		// Setup the miller
		strcat(file,"'OpenSBP file written by Harelet\n'Harelet, written by William King\n'No responsibilty is taken for any damages to any equipment\n\n'Starting\nSO, 1,1\nPause 2\nSA,\n&ZUP = 0.25\nMH\n\n'Bulk of instructions\n");

		for(int i = 0;i != numpoints;i++){

			char instruction[64];

			strcat(instruction,"J2 ");
			strcat(instruction,IntToString(points[i].X));
			strcat(instruction," ");
			strcat(instruction,IntToString(points[i].Y));
			strcat(instruction,"\n");

			if(points[i].down == 0){
				strcat(instruction,"MZ -0,0625\n");
			}
			else{
				strcat(instruction,"JZ,&ZUP\n");
			}

			strcat(file,instruction);
		}

		//Finished, add instructions to wait for the user
		strcat(file,"\nJ2,0,0\nSO, 1,0\n'All done. Wait for user.\nPAUSE");

		WriteFile(filename,file);

	}
	else{
		Warn("Invalid compiliation format");
	}

	puts("Finished compiling instructions");
	getchar();

}


/*********************************************
 * Description - Main function
 * Author - William King
 * Date - Sep 08 2023
 * *******************************************/
void main(int argc, char* argv[]){
	while(1){
		Render();
#ifndef DVORAK
		switch(getchar()){
			case 'h': 
				if(X - step >= 2){
					X -= step;
				}	
				break;
			case 'j': 
				if(Y + step < RESY - step){
					Y += step;
				}
				break;
			case 'k': 
				if(Y - step >= 2){
					Y -= step;
				}
				break;
			case 'l': 
				if(X + step < RESX - step){
					X += step;
				}
				break;
			case 's': 
				puts("New stepsize:");
				scanf("%d",&step);
				break;

			case 'a': 
				points[numpoints].X = X;
				points[numpoints].Y = Y;
				points[numpoints].down = down;
				numpoints++;
				break;
			case 'd':
				if(down == 1){
					down = 0;
				}
				else{
					down = 1;
				}
				break;
			case 'c': 
				Compile();
				break;
			case 'q':
				ClrScr();
				exit(0);
				break;
			default:
				break;
		}
#endif
#ifdef DVORAK
		switch(getchar()){
			case 'a': 
				if(X - step >= 2){
					X -= step;
				}	
				break;
			case 'o': 
				if(Y + step < RESY - step){
					Y += step;
				}
				break;
			case ',': 
				if(Y - step >= 2){
					Y -= step;
				}
				break;
			case 'e': 
				if(X + step < RESX - step){
					X += step;
				}
				break;
			case '.': 
				puts("New stepsize:");
				scanf("%d",&step);
				break;

			case ' ': 
				points[numpoints].X = X;
				points[numpoints].Y = Y;
				points[numpoints].down = down;
				numpoints++;
				break;
			case 'p':
				if(down == 1){
					down = 0;
				}
				else{
					down = 1;
				}
				break;
			case 'y': 
				Compile();
				break;
			case 'q':
				ClrScr();
				exit(0);
				break;
			default:
				break;
		}
#endif
	}

	exit(0);
}
