# Harelet 
A CNC CAD program for milling machine for xnix, Win32, and DOS platforms.s
You may export RAW gcode or for Shopbot machines (OpenSBP) 
To configure settings edit the definitions in 
the source code and recompile easily by executing the 
compile script. By default the units are Imperial.

---

## USAGE

All controls are lowercase.

Vim keys to move(HJKL).
         k  
        h l
         j
H Left
J Down
K Up
L Right


A to add a point at the current cursor's position

Q to exit

D to set cursor down or raised

C to compile instructions for a machine, you will be prompted for a filename

S to change step size, how far the cursor moves at a time

---

## DVORAK

Harelet has built in Dvorak support, compile with -DVORAK.

Keys for QWERTY to DVORAK

, - Up
A - Left
O - Down
E - Right
X - Exit
p - Set DWN
Y - Compile
. - Set step size
Space - Add point

## CONTRIUTIONS

Notes on commits

Keep it granular

Keep it (C)imple

Keep it consistent with the vision

---

## FILEMAP

based - Based Libraries
examples - Example files made with Harelet to test
win32 - Windows and DOS executables
c.ksh - Compile script
README.md - This
harelet.c - Harelet source code
BUGS - Write bugs here
HARELET.MAN - Manual page
harelet  - Harelet exectable for Linux
hareletdvrk  - Harelet exectable for Linux (Dvorak)


