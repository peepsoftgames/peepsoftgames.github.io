var searchData=
[
  ['points_0',['points',['../harelet_8c.html#a006956fd35b2b917de183603e6375a62',1,'harelet.c']]]
];
