var searchData=
[
  ['numpoints_0',['numpoints',['../harelet_8c.html#af9cc4f618d43afb0485872db7ecb8b01',1,'harelet.c']]]
];
