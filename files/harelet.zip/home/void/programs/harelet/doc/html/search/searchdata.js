var indexSectionsWithContent =
{
  0: "acdhimnprsuwxy",
  1: "p",
  2: "hr",
  3: "cimrw",
  4: "adnpsxy",
  5: "dmsu",
  6: "h"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "defines",
  6: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Macros",
  6: "Pages"
};

