var searchData=
[
  ['deepness_0',['DEEPNESS',['../harelet_8c.html#ab4de6a271947e7899963fa099a9b106d',1,'harelet.c']]],
  ['down_1',['down',['../structpoint.html#a17b6e97a62a0a92f885381869fc7e9a1',1,'point::down'],['../harelet_8c.html#a757bf973f8d93e7a06ca4e8240a0a552',1,'down:&#160;harelet.c']]]
];
