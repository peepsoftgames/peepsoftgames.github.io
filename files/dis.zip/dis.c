//Displays a program, alternative to "cat", uses my based file library
#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include "basedfilelib.h"

void main(int argc, char* argv[]){
	if (argc == 1 ) { puts("Dis by William King at Peep Soft\nDisplays a file to stdout, better than cat at this purpose\nUsage: dis (file)");exit(0);}
	//puts("Displaying:");
	char * filetoread = argv[1];
	char * file = ReadFile(filetoread);
	//printf("Contents of argv: %s\n",*argv);
	//printf("Reading file: %s\n",filetoread);

	while(strlen(file) != 0){
		//char * print = ReadLine(file,1);
		printf("%s\n",ReadLine(file,1));
		DeleteLine(file,1);
	}
	exit(0);
}

