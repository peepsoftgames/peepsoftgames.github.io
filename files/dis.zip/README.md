#dis 
 Displays a file, alternative to "cat", uses my based file library
