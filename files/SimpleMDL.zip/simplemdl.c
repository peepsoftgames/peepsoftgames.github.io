// Simplemdl is a simple CLI Source Engine model compiling front end written in C that beats all the other programs written in horrendous .NET and VB

// Built using the only C compiler https://bellard.org/tcc/

#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void Compile(const char* folderPath, const char* arguments) {
    printf("Sending instructions to compiler...\n");

    // run the compilation command using folderPath and arguments
    char command[256];
    snprintf(command, sizeof(command), "cd \"%s\" && studiomdl.exe %s", folderPath, arguments);
    system(command);
}

void Settings() {
    int choice;

    printf("1. Change HL2 bin folder location\n");
    printf("2. Change compiler parameters\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1: {
            char binFolderPath[256];
            printf("Paste the location of your Half Life 2's bin folder by right clicking: ");
            scanf("%s", binFolderPath);
			//save
            FILE* file = fopen("simplemdloptions.txt", "w");
            if (file != NULL) {
                fprintf(file, "BinFolderPath: %s\n", binFolderPath);
                fclose(file);
                printf("HL2 bin folder location saved: %s\n", binFolderPath);
            } else {
                printf("Failed to save the HL2 bin folder location.\n");
            }
            break;
        }
        case 2: {
            char arguments[256];
            printf("Type in your argument options for studiomdl: ");
            scanf(" %[^\n]", arguments);

            // save
            FILE* file = fopen("simplemdloptions.txt", "a");
            if (file != NULL) {
                fprintf(file, "CompilerArguments: %s\n", arguments);
                fclose(file);
                printf("Compiler parameters saved: %s\n", arguments);
            } else {
                printf("Failed to save the compiler parameters.\n");
            }
            break;
        }
        default:
            printf("Invalid choice. Please try again.\n");
            break;
    }
}

void Decompile(const char* folderPath) {
    printf("Sending instructions to decompiler...\n");

    // run the decompilation command using folderPath
    char command[256];
    snprintf(command, sizeof(command), "cd \"%s\" && decompiler.exe", folderPath);
    system(command);
}

int main(void) {
    int choice;
	printf("Made by Vilyaem Kenyaz at vilyaemkenyaz.net");
	printf("Donate Monero: 47Ras3tQjpRLeBNAjq2ZYb1T6ZRsqMvymAmYiEXZtDV6YfZuKSMHPbuZEVUgynAcPXhNVaUFJtYZMVBYoFHuHHCU8Jjd9Jj");
    printf("Welcome to Simplemdl, select a mode\n");
    printf("1. Compile\n");
    printf("2. Decompile\n");
    printf("3. Settings\n");
    printf("Enter your choice: ");
    scanf("%d", &choice);

    switch (choice) {
        case 1: {
            printf("You chose Compile\n");

            char folderPath[256];
            printf("Enter the folder path of the models you would like to compile: ");
            scanf(" %[^\n]", folderPath);

            char arguments[256];
            printf("Enter the argument options for studiomdl: ");
            scanf(" %[^\n]", arguments);

            Compile(folderPath, arguments);
            break;
        }
        case 2: {
            printf("You chose Decompile\n");

            char folderPath[256];
            printf("Enter the folder path of the models you would like to decompile: ");
            scanf(" %[^\n]", folderPath);

            Decompile(folderPath);
            break;
        }
        case 3:
            printf("You chose Settings\n");
            Settings();
            break;
        default:
            printf("Invalid choice. Please try again.\n");
            break;
    }

    return 0;
}
