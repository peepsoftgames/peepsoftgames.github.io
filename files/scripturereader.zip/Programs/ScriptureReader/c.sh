#!/bin/sh
rm scripturereader
clear
printf "Compiling\n"
tcc scripturereader.c -o scripturereader
cp scripturereader /usr/bin/
