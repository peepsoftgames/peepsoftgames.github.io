#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define PAGE_SIZE 50

void print_page(const char* filename, int page_number, int total_pages) {
    system("clear");
    printf("---SCRIPTURE-READER---\n");
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file: %s\n", filename);
        exit(1);
    }

    char line[256];
    int line_count = 0;
    int current_page = 1;

    while (fgets(line, sizeof(line), file)) {
        line_count++;
        if (line_count > (page_number - 1) * PAGE_SIZE && line_count <= page_number * PAGE_SIZE) {
            printf("%s", line);
        }
        if (line_count > page_number * PAGE_SIZE) {
            break;
        }
    }

    fclose(file);

    printf("\n--- Page %d of %d ---\n", page_number, total_pages);
}

int get_total_pages(const char* filename) {
    FILE* file = fopen(filename, "r");
    if (file == NULL) {
        printf("Error opening file: %s\n", filename);
        exit(1);
    }

    char line[256];
    int line_count = 0;

    while (fgets(line, sizeof(line), file)) {
        line_count++;
    }

    fclose(file);

    return (line_count + PAGE_SIZE - 1) / PAGE_SIZE;
}

int main(int argc, char* argv[]) {
    if (argc < 2 || argc > 3) {
        printf("ScriptureReader by William @ peepsoftgames.github.io thekenyaz@yandex.com\n");
        printf("Usage:\n");
        printf("  scripturereader <textfile>\n");
        return 1;
    }

    const char* filename = argv[1];

    int total_pages = get_total_pages(filename);
    int current_page = 1;

    while (1) {
        system("clear");
        print_page(filename, current_page, total_pages);

        char ch;
        scanf(" %c", &ch);
        switch (ch) {
            case 'l':
            case 'L':
 if (current_page > 1) {
                    current_page--;
                }
                break;
            case 'r':
            case 'R':
 if (current_page < total_pages) {
                    current_page++;
                }
                break;
            case 'q':
            case 'Q':
 exit(0);
        }
    }

    exit(0);
}

