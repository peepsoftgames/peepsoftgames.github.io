os.execute('color e')

print("Welcome to WRSSE!")
print("Press newline twice to exit the editor and save your work")

--[[
WRSSE is a simple LUA based RSS feed editor for Windows
--]]

-- function to parse feed items
function parse_items(items)
  local parsed_items = ""
  for _, item in ipairs(items) do
    parsed_items = parsed_items .. string.format([[
<item>
  <title>%s</title>
  <link>%s</link>
  <description>%s</description>
</item>
]], item.title, item.link, item.description)
  end
  return parsed_items
end

-- default
local feed_path = "feed.rss"

-- check if exists already
if io.open(feed_path, "r") then
  io.write("Feed file found. Would you like to edit it? (y/n): ")
  local input = io.read()
  if input == "y" or input == "Y" then
    local feed_items = {}

    -- parse
    local feed_file = io.open(feed_path, "r")
    local feed_contents = feed_file:read("*all")
    feed_file:close()

    for item_title, item_link, item_description in feed_contents:gmatch("<item>\n%s-<title>(.-)</title>\n%s-<link>(.-)</link>\n%s-<description>(.-)</description>\n%s-</item>") do
      table.insert(feed_items, {title = item_title, link = item_link, description = item_description})
    end


    local item_title = ""
    local item_link = ""
    local item_description = ""
    while true do
      io.write("Title (leave blank to finish): ")
      item_title = io.read()
      if item_title == "" then
        break
      end
      io.write("Link: ")
      item_link = io.read()
      io.write("Description: ")
      item_description = io.read()
      table.insert(feed_items, {title = item_title, link = item_link, description = item_description})
    end

    -- format
    local formatted_feed = string.format([[
<rss version="2.0">
<channel>
<title>%s</title>
<link>%s</link>
<description>%s</description>
%s
</channel>
</rss>
]], feed_title, feed_link, feed_description, parse_items(feed_items))

    -- append
    local file = io.open(feed_path, "a")
    file:write(formatted_feed)
    file:close()

    print("Feed successfully updated!")
  else
    print("Exiting without making any changes.")
  end
else
  io.write("Feed file not found. Would you like to create a new file? (y/n): ")
  local input = io.read()
if input == "y" or input == "Y" then
local feed_items = {}

io.write("Enter feed information:\n")
io.write("Title: ")
local feed_title = io.read()
io.write("Link: ")
local feed_link = io.read()
io.write("Description: ")
local feed_description = io.read()


local item_title = ""
local item_link = ""
local item_description = ""
while true do
  io.write("Title (leave blank to finish): ")
  item_title = io.read()
  if item_title == "" then
    break
  end
  io.write("Link: ")
  item_link = io.read()
  io.write("Description: ")
  item_description = io.read()
  table.insert(feed_items, {title = item_title, link = item_link, description = item_description})
end

--format
local formatted_feed = string.format([[
<rss version="2.0">
<channel>
<title>%s</title>
<link>%s</link>
<description>%s</description>
%s
</channel>
</rss>
]], feed_title, feed_link, feed_description, parse_items(feed_items))

local file = io.open(feed_path, "w")
file:write(formatted_feed)
file:close()

print("Feed successfully created!")
else
print("Exiting without creating a feed.")
end
end

