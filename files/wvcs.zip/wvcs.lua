-- This is a version control system contained within a single lua script. There is two functions Paint Mode and Archive mode
-- Paint mode takes the contents of a folder1 compares it with another folder2 archives the folder2, writes the difference between folder1 and folder2 into the archive folder, then pastes the contents of folder1 onto folder2
-- Like paint on a wall
--Archive mode takes a folder1 then an archive folder and produces an archive of the contents of folder1 in the archive folder

os.execute('color 10') 
print("Welcome to Williams Version Control System! \n")

 
function PaintMode()
  print("Enter PaintDirectory:")
  local PaintDirectory = io.read()
  print("Enter WallDirectory:")
  local WallDirectory = io.read()
  print("Enter Archivedirectory:")
  local Archivedirectory = io.read()

  -- count files and folders
  local PaintDirectory_files = 0
  local PaintDirectory_folders = 0
  
  for file in io.popen('dir "'..PaintDirectory..'" /b /a-d | "C:\\Windows\\System32\\find.exe" /c /v ""'):lines() do
    PaintDirectory_files = file
  end
  
  for folder in io.popen('for /d %d in ("'..PaintDirectory..'\\*") do @echo.'):lines() do
    PaintDirectory_folders = folder
  end

  -- go to the directory of WallDirectory and count all the files and folders
  local WallDirectory_files = 0
  local WallDirectory_folders = 0
  
  for file in io.popen('dir "'..WallDirectory..'" /b /a-d | "C:\\Windows\\System32\\find.exe" /c /v ""'):lines() do
    WallDirectory_files = file
  end
  
  for folder in io.popen('for /d %d in ("'..WallDirectory..'\\*") do @echo.'):lines() do
    WallDirectory_folders = folder
  end
  
  -- print numbers
  print("Number of files in "..PaintDirectory..": "..PaintDirectory_files)
  print("Number of folders in "..PaintDirectory..": "..PaintDirectory_folders)
  print("Number of files in "..WallDirectory..": "..WallDirectory_files)
  print("Number of folders in "..WallDirectory..": "..WallDirectory_folders)

  -- make folder with date as its name
  local date = os.date("%Y%m%d%H%M%S")
  local command = "mkdir "..Archivedirectory.."\\"..date
  os.execute(command)

  print("Enter a note:")
  local note = io.read()
  local diff_file = io.open(Archivedirectory.."\\"..date.."\\diff.diff", "w")
  diff_file:write(note.."\n\n")

  -- Find the names of files that do not exist in WallDirectory but exist in PaintDirectory
  -- and all the names of files in PaintDirectory that have a counterpart in WallDirectory
  -- but have a newer date modified
  for file in io.popen('"C:\\Windows\\System32\\fc.exe" /b "'..PaintDirectory..'" "'..WallDirectory..'"'):lines() do
    local modified_time1 = io.popen('dir /T:W "'..PaintDirectory..'\\'..file..'"'):lines()
    local modified_time2 = io.popen('dir /T:W "'..WallDirectory..'\\'..file..'"'):lines()
    if modified_time1 > modified_time2 then
      diff_file:write(file.."\n")
    elseif string.sub(file, 1, 2) == "FC" then
      diff_file:write(string.sub(file, 26).."\n")
    end
  end
  end

function ArchiveMode()
  print("Enter folder in which the contents you'd like to archive:")
  local folder1 = '"'..io.read()..'"'
  print("Enter the folder in which you'd like the archive to be stored:")
  local archive_folder = '"'..io.read()..'"'

  -- Count the number of files in folder1 and print the result
  local file_count = 0
  for file in io.popen('dir '..folder1..' /b /a-d | "C:\\Windows\\System32\\find.exe" /c /v ""'):lines() do
    file_count = file
  end
  print("Number of files in "..folder1..": "..file_count)

  -- create a folder with the current date in the archive folder
  local date = os.date("%Y%m%d%H%M%S")
  local command = 'mkdir '..archive_folder..'\\'..date
  os.execute(command)

  -- paste the contents of folder1 into the folder with the current date as its name
  command = "C:\\Windows\\System32\\xcopy.exe /E /I /Y "..folder1.." "..archive_folder..'\\'..date
  os.execute(command)
  
  print("Enter a note:")
  local note = io.read()
  local diff_file = io.open(archive_folder.."\\"..date.."\\diff.diff", "w")
  diff_file:write(note.."\n\n")
  
  MainMenu()
end

function MainMenu()
  print("Select the mode you'd like to use:")
  print("1. PaintMode")
  print("2. ArchiveMode")

  local selection = io.read()

  if selection == "1" then
    PaintMode()
  elseif selection == "2" then
    ArchiveMode()
  end
end

-- run MainMenu on start
MainMenu()

MainMenu()
